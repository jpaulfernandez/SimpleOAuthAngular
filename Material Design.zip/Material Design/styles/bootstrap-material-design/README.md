# bootstrap-material-design

[`v4.0.2`](../../releases/tag/v4.0.2) built from commit [`f2ac8b1`](../../commit/f2ac8b142aba7e0cda5c945b04649269d1ff3d5a) on branch `v4-dev`. See the [README](../..) for more details

---
<sup>Built and published by [gulp-pipeline](https://github.com/alienfast/gulp-pipeline) using [build-control](https://github.com/alienfast/build-control)</sup>
